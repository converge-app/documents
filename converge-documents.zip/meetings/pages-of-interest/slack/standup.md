# Standup

```text
*What did you do since yesterday?*

*What will you do today?*

```

