# Gantt

{% embed url="https://app.teamgantt.com/projects/people?ids=1790284&currentId=1790284" %}

