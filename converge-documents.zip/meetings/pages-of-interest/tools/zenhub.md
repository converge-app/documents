# Zenhub

{% embed url="https://app.zenhub.com/workspaces/scrum-5d0902e618933759855cd220/board?repos=192566934" %}

Send a message my way at @kjuulh on slack

