# Test person meeting 2019-09-11

## Information:

* Participants:
  * [ ] Kasper J. Hermansen
  * [ ] Victor B. Levesen
* Location:
  * Grenåvej 762 St
* Date:
  * 2019-09-11
* Duration:
  * 16:30-17:30

## Summary

* Test person liked the design
* He wanted a more interactive onboarding
* Liked the design, but wanted more information on the different pages, especially the pages where there was interaction between the freelancer and employer
* Wanted more separation between being a freelancer and employer.
* More fine grained control over interactions with others. \(Audit trail\)

