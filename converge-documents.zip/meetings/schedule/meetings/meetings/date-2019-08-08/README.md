# Date 2019-08-08

* Design change palette to white

