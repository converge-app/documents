# Supervisor metting 2019-10-31

## Information: <a id="information"></a>

* Participants:
  * Kasper J. Hermansen
  * Sameer A. Habibi
  * Jesper M. Kristensen
* Location:
  * Kahn 250
    * Password: 2244
* Date:
  * 2019-10-31
* Duration:
  * 12:30-13:00

## Agenda: <a id="agenda"></a>

* Schedule for the last months
* Demo
  * The whole app \(hopefully\)
* Accepttest \(start\)
* Outstanding issues regarding the system
  * The plan to create bug reports and fixing them
  * Creating tests to gain confidence in the system
* Sprint 10 start
  * And schedule \(teamgantt\)
* Releases
  * Release dates
* Planned documentation
* Questions
  * I forhold til evalueringsexcel ark. Hvad menes der med:
    * Domæneforståelse, er det domæne model og reflektion i forhold til krav
    * Baggrunden for projektet er beskrevet og relateret til projektformuleringen, vi ved ikke helt hvad der menes med denne sektion og hvad det skal munde ud i.
    * Impact, menes det om det er samfunds eller arkitekturisk betydning.

‌

