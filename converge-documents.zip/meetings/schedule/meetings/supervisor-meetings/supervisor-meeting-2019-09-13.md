# Supervisor meeting 2019-09-13

## Information:

* Participants:
  * [ ] Kasper J. Hermansen
  * [ ] Sameer A. Habibi
  * [ ] Jesper M. Kristensen
* Location:
  * Kahn 250
    * Password: 2244
* Date:
  * 2019-09-13
* Duration:
  * 12:30-13:30

## Agenda:

* Demo
  * Feedback from test person
    * Concept, rearrange some functionality
    * MoSCoW revisited
  * Requirements specification draft
  * Login, Signup
    * Authentication
    * Authorization
  * Webapp
    * Login
    * Sign up
    * Dashboard
* Schedule
  * What do we think of our progress, are we on track
    * We feel so.
* Scrum retro recap
  * Changed the way we estimate and do tasks
    * Switched to a feature based system
* Requirement spec structure and content
* Maybe got another test person & proofreader



## Resume

