# Supervisor meeting 2019-10-11

## Information:

* Participants:
  * [ ] Kasper J. Hermansen
  * [ ] Sameer A. Habibi
  * [ ] Jesper M. Kristensen
* Location:
  * Kahn 250
    * Password: 2244
* Date:
  * 2019-10-11
* Duration:
  * 12:30-13:00

## Agenda:

* Sprint intro and plan
  * Goal is to complete the projects flow, left over from last sprint
  * Next is to code the text chat service and create payments.
  * We lack quite a bit of frontend code, and we've found out that it takes quite a bit longer to do, than backend. \(Mostly because we aren't as experienced in it.\)
* Phillip has become a reviewer for our requirements spec, and other documents that are done. He probably won't proofread, another person has that job.
* We're gonna add some things to our boundary constraints. Such as video chat, certain logon features, and some specific project features and security non-functional requirements.
* This is the last sprint of coding, before we begin focusing on the written contents.
  * We're gonna try finishing the first part of the System interfaces this sprint as well. 

