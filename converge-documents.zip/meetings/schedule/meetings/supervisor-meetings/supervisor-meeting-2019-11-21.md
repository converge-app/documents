# Supervisor meeting 2019-11-21

## Information: <a id="information"></a>

* Participants:
  * Kasper J. Hermansen
  * Sameer A. Habibi
  * Jesper M. Kristensen
* Location:
  * Kahn 250
    * Password: 2244
* Date:
  * 2019-11-21
* Duration:
  * 12:30-13:00

## Agenda: <a id="agenda"></a>

* Status
  * Documents written
  * Documents that need to be written/finished
  * Report overview
    * Faster than expected.
    * Sent for corrections
  * Update on writing tests
* Started on a new sprint
  * Report
* Update on questions from last meeting

