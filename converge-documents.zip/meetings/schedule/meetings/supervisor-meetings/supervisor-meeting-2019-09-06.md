# Supervisor meeting 2019-09-06

## Information:

* Participants:
  * [ ] Kasper J. Hermansen
  * [ ] Sameer A. Habibi
  * [ ] Jesper M. Kristensen
* Location:
  * Kahn 250
    * Password: 2244
* Date:
  * 2019-09-06
* Duration:
  * 12:30-13:30

## Agenda:

* Demo
  * Applikation \(Draft\)
    * Forside
    * About
    * Freelancer
  * Backend
    * Login \(muligvis\)
  * Meta application
    * Tracing
    * Logging
  * Krav specification
    * Overordnede krav
      * MoSCoW
      * Funktionelle Krav
  * User tests \(Victor\) I løbet af næste uge
  * Spørgsmål
    * Brug af open source biblioteker \(og værktøjer\)
    * Agil opdeling
      * Initiatives
      * Epics
      * User stories

## Resume

* Demo
  * Applikation \(Draft\)
    * Forside
    * About
    * Freelancer
  * Backend
    * Login \(muligvis\)
  * Meta application
    * Tracing
    * Logging
  * Krav specification
    * Overordnede krav
      * MoSCoW
      * Funktionelle Krav
  * User tests \(Victor\) I løbet af næste uge
  * Spørgsmål
    * Brug af open source biblioteker \(og værktøjer\)
    * Agil opdeling
      * Initiatives
      * Epics
      * User stories
    * Kompetance vurdering til næste vejleder møde
    * Send kravspec inden onsdag.
    * Agil manifest & Martin Fowler.





