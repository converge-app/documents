# Spring 6

1. **What went well**
   1. Små opgaver var fint. 
      1. Men, estimering af dem var et problem
   2. Være flere, og have struktrurede sprintplanlægning
2. **What could we do better**
   1. Estimering af opgaver
   2. Estimering af hvor meget vi kunne nå passede ikke helt
3. **What can we do next time**
   1. Bruger epics til opgaver. Så opgaver bliver større og man derfra kan lave mindre opgaver der er små og passer til et område og ikke en feature.

