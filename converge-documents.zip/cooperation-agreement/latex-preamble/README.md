# Latex Preamle

To be included at the root of other Converge documentation latex documents

