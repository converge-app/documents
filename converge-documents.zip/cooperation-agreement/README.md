# Requirement specification docs

## Dependencies

texlive, biber etc.

